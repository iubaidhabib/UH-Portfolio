// Place any global data in this file.
// You can import this data from anywhere in your site by using the `import` keyword.

export const SITE_TITLE = 'Ubaid Habib - Software Engineer';
export const SITE_DESCRIPTION = 'Portfolio and blog of Ubaid Habib, a software engineer specializing in web development and full-stack solutions.';

export const CONTACT = {
  email: '4ubaidk9@gmail.com',
  github: 'https://github.com/ubaidhabib',
  linkedin: 'https://linkedin.com/in/ubaid-habib-84193b307'
};

export const SKILLS = {
  languages: ['JavaScript', 'TypeScript', 'Python', 'Java'],
  frameworks: ['React', 'Node.js', 'Express', 'Next.js', 'Astro'],
  tools: ['Git', 'Docker', 'MongoDB', 'PostgreSQL', 'REST APIs'],
  methodologies: ['Agile', 'DevOps', 'Full-Stack Development', 'CI/CD']
};

export const PROJECTS = [
  {
    title: 'E-commerce Platform',
    description: 'Built a scalable e-commerce platform with modern features',
    technologies: ['React', 'Node.js', 'PostgreSQL', 'Express'],
    role: 'Full Stack Developer',
    outcome: 'Successfully implemented complete e-commerce functionality',
    link: 'https://github.com/ubaidhabib/ecommerce'
  },
  {
    title: 'Task Management System',
    description: 'Developed a comprehensive task management application',
    technologies: ['Next.js', 'MongoDB', 'Express', 'Node.js'],
    role: 'Full Stack Developer',
    outcome: 'Created an efficient system for task organization and tracking',
    link: 'https://github.com/ubaidhabib/task-manager'
  },
  {
    title: 'Portfolio Website',
    description: 'Created a modern portfolio website using Astro',
    technologies: ['Astro', 'TypeScript', 'Tailwind CSS'],
    role: 'Frontend Developer',
    outcome: 'Developed a fast and responsive portfolio showcase',
    link: 'https://github.com/ubaidhabib/portfolio'
  }
];

export const ACHIEVEMENTS = [
  {
    title: 'Academic Excellence',
    description: 'Maintaining CGPA above 3.5 at AUST'
  },
  {
    title: 'Full Stack Development',
    description: 'Proficient in both frontend and backend technologies'
  }
];